import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, tap } from 'rxjs';
import { Contract } from './contract';


@Injectable({
  providedIn: 'root'
})
export class ContractsService {
  constructor(private httpClient:HttpClient){ }
    baseUrl:string="http://localhost:8080/newContract";
    Url:string="http://localhost:8080/contracts";
    getContracts(){
     return this.httpClient.get(this.Url);
    
    }
    search(query:string):Observable<any[]>{
      return this.httpClient.get<any[]>('${this.baseUrl}?search=${query}');

    }
    createContract(contract:Contract):Observable<any>{
      return this.httpClient.post<any>(this.baseUrl,contract)
    }
    getContracctById(){
      return this.httpClient.get("http://localhost:8080/getContractById/{id}")
    }
    postContract(body: { contractId: Number; prismId: string; offshoreHC: string; onsiteHC: string; offsiteHC: string; onsitePM: string; onsiteDM: string; offshorePM: string; offshoreDM: string; offshoreDMSap: string; offshorePMSap: Number; contractStartDate: Date; contractEndDate: Date; vendor: string; sOWName: string; engagementType: string; contractType: string; relationship: string; costManagement: string; quality: string; delivary: string; resources: string; region: string; contractMgr: string; contactDirector: string; valueAddedResources: string; opco: string; contactAccessNo: string; additionPMAcessSap: string; contactAccessYes: string; clientManager: string; clientManagerLDAP: string; clientDir: string; clientDirLDAP: string; clientVP: string; clientVPLDAP: string; clientSVP: string; defaultManager: boolean; }){
      console.log(body);
      return this.httpClient.post(this.baseUrl,body)
    }
    public downloadFile(){
     return this.httpClient.get("http://localhost:8080/users/export/excel",
      {observe:'response',responseType:'blob'})
    }
    downloadExcel():void{
      this.httpClient.get("http://localhost:8080/users/export/excel",{
        responseType:'blob'
      }).subscribe((data:Blob)=>{
      const blob=new Blob([data],{type:'application/octet-stream'});
      const url=window.URL.createObjectURL(blob);
      const a=document.createElement('a');
      a.href=url;
      a.download='contracts.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

    })
    }
    getdisplay(){
      return []
    }
  }
