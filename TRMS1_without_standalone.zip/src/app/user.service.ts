import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  username:string;
    password:string;
    constructor(){
        this.username='username';
        this.password='password';
    }
    setUsername(username:string){
        this.username=username;
    }
    getUsername():string{
      return this.username;
    }
}
