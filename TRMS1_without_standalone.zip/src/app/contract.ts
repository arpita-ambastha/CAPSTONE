
export class Contract{
    contractId:string;
    clientPM:string;
    clientVp:string;
    clientSvp:string;
    clientDirector:string;
    contactMgr:string;
    offshorePm:string;
    contractstartDate:string;
    contractendDate:string;
    constructor(){
        this.contractId='contractId';
        this.clientPM='clientPM';
        this.clientVp='clientVp';
        this.clientSvp='clientSvp';
        this.clientDirector='clientDirector';
        this.contactMgr='contactMgr';
        this.offshorePm='offshorePm';
        this.contractstartDate='contractstartDate';
        this.contractendDate='contractendDate';
    }
}