import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { ContractComponent } from './contract/contract.component';
import { VmoComponent } from './vmo/vmo.component';

const routes: Routes = [
  {path:'',redirectTo:'/loginpage',pathMatch:'full'},
  {path:'loginpage', component:LoginpageComponent},
  {path:'contract',component:ContractComponent},
  {path:'vmo',component:VmoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
