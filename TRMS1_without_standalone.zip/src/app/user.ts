export class User {
    username:string;
    password:string;
    constructor(){
        this.username='username';
        this.password='password';
    }
 
}