import { Resources } from './resources';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { VmoComponent } from './vmo/vmo.component';
import { Vmo } from './vmo';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Contract } from './contract';

@Injectable({
  providedIn: 'root'
})
export class VmoService {
  resourceData: boolean=false;

  private apiUrl ="http://localhost:8080/update/{fedex_ID}";
  // resourceBeingEdited: null;
  resources: any;
  resourceBeingEdited: null | undefined;
  constructor(private httpClient:HttpClient) { }
  baseUrl:string="http://localhost:8080/createvmo";
  Url:string="http://localhost:8080/contracts";
  url1:string="http://localhost:8080/viewAllVmoResources/{contractId}";
  url2:string="http://localhost:8080/viewAllVmoResources";

  // @returns Observable<any[]>

// getResources():Observable<any[]> {
//   return this.http.get<any[]> ('${this.apiUrl}/resources',Resources).pipe(

//     catchError(this.handleError)
// );
// }
// @param id: any
// @param (Resources: any)
// // @returns Observable
// deleteResource (id: string): Observable<any>{
//   return this.http.delete<any>(`${this.apiUrl}/${id}`).pipe(
//     catchError(this.handleError) // Handle any errors
// );
// }
// @param error()
// @returns

// private handleError(error: HttpErrorResponse): Observable<any> {
//   console.error('An error occurred:', error);
  // Customize the error handling as needed
  // function returns throwError('Something went wrong; please try again later.');
// }




  postVmo(body: {
      fedexId: string; fedex_IdRequestedDate: Date; releaseRequestedDate: Date; visatype: string; cardrole: string; fedexVenderBadge: boolean; l1certification: string; l2certification: string; mphasissecuritytraining: string; sapId: string; fedex_idcreationdate: Date; releaseacknowledagedate: Date;
         location: string; clientmanager1: string; bgvinitiation1: boolean; fedexsecuritytraining1: string; clearence: boolean; name: string; billable: string; placement: string; companyname: string; systemacess: string; supplychain: boolean; hubstack: boolean; shipping: boolean;contractId: Number;contract:any;
    }){
    console.log(body);
    return this.httpClient.post(this.baseUrl,body)
  }
  getResources(){
    return this.httpClient.get(this.url2);
  }

  getResourcesById (fedexId:string):any| null{
    return this.httpClient.get(this.apiUrl);
  }
  updateResource (updatedResource:any):void{
    for (let i=0; i< this.resources.length;i++){
      if (this.resources[i].fedexId === updatedResource.fedexId){
        this.resources[i] = updatedResource;
        break;

      }
    }
    // const index = this.getResources.findIndex((r: {fedexId:string;}) =>r.fedexId ===updatedResource.fedexId);
    // if (index !== -1) {
    //   this.resources[index]=updatedResource;
    // }
    // this.resourceBeingEdited = null;
  }

  downloadVmo(){
    this.httpClient.get("http://localhost:8080/vmo/vmoexcel",{
        responseType:'blob'
      }).subscribe((data:Blob)=>{
      const blob=new Blob([data],{type:'application/octet-stream'});
      const url=window.URL.createObjectURL(blob);
      const a=document.createElement('a');
      a.href=url;
      a.download='Download_Report_Vmo.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

    })
  }
    getContracts(){
     return this.httpClient.get(this.Url);

    }
    getdisplay(){
      return []
    }
    saveVmo(vmo:Vmo):Observable<Vmo>{
      return this.httpClient.post<Vmo>(this.baseUrl,vmo);
    }

    view1(){
     return this.httpClient.get("http://localhost:8080/contracts")
    }
    view2(){
     return this.httpClient.get("http://localhost:8080/vmo")
    }


     getVmo(contractId: number): Observable<any> {
      const getVmoById="http://localhost:8080/vmo/"+contractId;
      return this.httpClient.get<any>(getVmoById);
    }
    VmoDownload(contractId:number):Observable<HttpResponse<Blob>>{
      const getById="http://localhost:8080/vmo/contract/vmoexcel/"+contractId;
      return this.httpClient.get(getById,{responseType:'blob',observe:'response'});
    }
}
function returns(target: VmoService, propertyKey: 'postVmo', descriptor: TypedPropertyDescriptor<(body: { fedexId: string; fedex_IdRequestedDate: Date; releaseRequestedDate: Date; visatype: string; cardrole: string; fedexVenderBadge: boolean; l1certification: string; l2certification: string; mphasissecuritytraining: string; sapId: string; fedex_idcreationdate: Date; releaseacknowledagedate: Date; location: string; clientmanager1: string; bgvinitiation1: boolean; fedexsecuritytraining1: string; clearence: boolean; name: string; billable: string; placement: string; companyname: string; systemacess: string; supplychain: boolean; hubstack: boolean; shipping: boolean; contractId: Number; contract: any; }) => Observable<Object>>): void | TypedPropertyDescriptor<(body: { fedexId: string; fedex_IdRequestedDate: Date; releaseRequestedDate: Date; visatype: string; cardrole: string; fedexVenderBadge: boolean; l1certification: string; l2certification: string; mphasissecuritytraining: string; sapId: string; fedex_idcreationdate: Date; releaseacknowledagedate: Date; location: string; clientmanager1: string; bgvinitiation1: boolean; fedexsecuritytraining1: string; clearence: boolean; name: string; billable: string; placement: string; companyname: string; systemacess: string; supplychain: boolean; hubstack: boolean; shipping: boolean; contractId: Number; contract: any; }) => Observable<Object>> {
  throw new Error('Function not implemented.');
}

function param(target: VmoService, propertyKey: 'id'): void {
  throw new Error('Function not implemented.');
}

