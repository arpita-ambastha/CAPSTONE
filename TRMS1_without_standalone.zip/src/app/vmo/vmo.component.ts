import { Component, OnInit } from '@angular/core';
import { VmoService } from '../vmo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ContractsService } from '../contracts.service';
import { BlockParameter, ThisReceiver } from '@angular/compiler';
import { Contract } from '../contract';
import { Vmo } from '../vmo';
import { UserService } from '../user.service';
import { LoginuserService } from '../loginuser.service';
import { HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-vmo',
  templateUrl: './vmo.component.html',
  styleUrl: './vmo.component.css'
})
export class VmoComponent implements  OnInit{
  sharedData: any[] = [];
  resource:any[]=[];
  resources:any;
  //vmo!: Vmo;
  timeNow:any;
  username='';
  fedexId=0;
  fedex_IdRequestedDate!:Date;
  releaseRequestedDate!:Date;
  visatype="";
  cardrole="";
  fedexVenderBadge:boolean=false;
  l1certification="";
   l2certification="";
   mphasissecuritytraining="";
  sapId="";
  fedex_idcreationdate!:Date;
  releaseacknowledagedate!:Date;
  location="";
  clientmanager1="";
  bgvinitiation1:boolean=false;
  fedexsecuritytraining1="";
  clearence:boolean=false;
  name="";
  billable="";
  placement="";
  companyname="";
  systemacess="";
  supplychain:boolean=false;
  hubstack:boolean=false;
  shipping:boolean=false;
  contractId!:number;
  //contract:any;
  contract: any[]=[];

  selectedIndices:number[]=[];
  null!: Date;
  resourceData: boolean=false;
isfedexIdRequired: any;

  isSelected(index:number){
    return this.selectedIndices.includes(index);
  }
  review(index:number){
   // selectRowIndex:this.selectRowIndex;
   // this.selectRowIndex=index;
    if(this.isSelected(index)){
      this.selectedIndices.includes(index);
    }else{
      this.selectedIndices.push(index);
    }

  }
  total(contract:any):number{
    return contract.offshoreHC+contract.onsiteHC;
  }
  //selectRowIndex=0;
  contracts:any;
  index=0;
  opco="";
  clientManager="";
  clientVP="";
  clientSVP="";
  clientDir="";

  reource:any;

  reset(){
    this.fedexId=0,
    this.fedex_IdRequestedDate=this.null,
    this.releaseRequestedDate=this.null,
    this.visatype="",
    this.cardrole="",
    this.fedexVenderBadge=true,
    this.l1certification="",
    this.l2certification="",
    this.mphasissecuritytraining="",
    this.sapId="",
    this.fedex_idcreationdate=this.null,
    this.releaseacknowledagedate=this.null,
    this.location="",
    this.clientmanager1="",
    this.bgvinitiation1=false,
    this.fedexsecuritytraining1="",
    this.clearence=false,
    this.name="",
    this.billable="",
    this.placement="",
    this.companyname="",
    this.systemacess="",
    this.supplychain=false,
    this.hubstack=false,
    this.shipping=false,
    this.contract
    this.contractId=0;
  }
  paramValue=0;
  vmo!: Vmo;
  //contracts:any[];
  resouces:any;
  addResources() {
    // Push an empty object representing a new row to the contractManagerDetails array
    this.resources.push({
      fedexId:''
    });
  }

  resourceBeingEdited: any=null;
  constructor(private route:ActivatedRoute,private router:Router,private vmoService:VmoService,private contractService:ContractsService,private userservice:UserService){}

  ngOnInit(): void {
    this.timeNow = new Date();
    this.username=this.userservice.getUsername();

    console.log(this.username);
    this.contractService.getContracts().subscribe((contracts)=>
      {
        this.contracts=contracts;
      });
      this.resources=this.vmoService.getResources();
  }
  getVmo(contractId:number) {
    this.vmoService.getVmo(contractId).subscribe(data=>{
      this.resources=data;
      this.vmoService.getResources();
      console.log(this.resources);
     // this.VmoDownload(this.resources);
    })
  }
    downloadVmo(){
      this.vmoService.downloadVmo();
    }

    VmoDownload(contractId:number){
      //contractId:this.contractId;
      this.vmoService.VmoDownload(contractId).subscribe((response:HttpResponse<Blob>)=>{
        const blob=response.body;
        if(blob!==null){
        //const blob=new Blob([response],{type:'application/octet-stream'});
        const url=window.URL.createObjectURL(blob);
        const a=document.createElement('a');
        document.body.appendChild(a);
        a.style.direction='none';
        a.href=url;
        a.download='Vmo_Download_Report_Vmo.xlsx';
        a.click();
        document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
        }
    })
    }
    saveVmo(){
      const vmo:Vmo={
  fedexId:this.fedexId,
  fedex_IdRequestedDate:this.fedex_IdRequestedDate,
  releaseRequestedDate:this.releaseRequestedDate,
  visatype:this.visatype,
  cardrole:this.cardrole,
  fedexVenderBadge:this.fedexVenderBadge,
  l1certification:this.l1certification,
  l2certification:this.l2certification,
  mphasissecuritytraining:this.mphasissecuritytraining,
  sapId:this.sapId,
  fedex_idcreationdate:this.fedex_idcreationdate,
  releaseacknowledagedate:this.releaseacknowledagedate,
  location:this.location,
  clientmanager1:this.clientmanager1,
  bgvinitiation1:this.bgvinitiation1,
  fedexsecuritytraining1:this.fedexsecuritytraining1,
  clearence:this.clearence,
  name:this.name,
  billable:this.billable,
  placement:this.placement,
  companyname:this.companyname,
  systemacess:this.systemacess,
  supplychain:this.supplychain,
  hubstack:this.hubstack,
  shipping:this.shipping,
  contract:{
  contractId:this.contractId,
    }
  };
  this.vmoService.saveVmo(vmo).subscribe(savedVmo=>
    {
      console.log(savedVmo);
    }
  )
}

Resources():void{
  // this.vmoService.getResources.subscribe(
  //   data:any[]) => {
  //     this.resources= data;
  //   };
  //   (error: any)=> {
  //     console.error('Error fetching resources',error);
  //   }


}
editResource(resource: any): void {

  this.resourceBeingEdited = { ...resource };
}
updateResource(updatedResource: any): void {

const index = this.resources.findIndex((r: { fedexId: any; }) => r.fedexId === updatedResource.fedexId);


if (index !== -1) {
    this.resources[index] = updatedResource;
}


this.resourceBeingEdited = null;
}
cancelEdit(): void {

this.resourceBeingEdited = null;
}
}
