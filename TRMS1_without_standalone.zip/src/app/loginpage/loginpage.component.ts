import { Component, OnInit } from '@angular/core';
//import { User } from '../user';
//import { LoginuserService } from '../loginuser.service';
import { Router } from '@angular/router';
import { __values } from 'tslib';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginuserService } from '../loginuser.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrl: './loginpage.component.css'
})
export class LoginpageComponent implements OnInit{
    user:UserService ={} as UserService;
    username:string="";
  constructor(private router:Router,private loginService:LoginuserService){
   
  }
  ngOnInit(): void { }
    
  userlogin(){
      console.log(this.user)
      this.loginService.loginuser(this.user).subscribe(data=>{
        console.log(data),
        this.router.navigate(['/contract']);
      })
  }
}