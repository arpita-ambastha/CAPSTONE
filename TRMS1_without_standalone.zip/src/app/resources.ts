export class Resources {
    fedexId:string;
    name:string;
    placement:string;
    billable:string;
    constructor(){
        this.fedexId='fedexId';
        this.name='name';
        this.placement='placement';
        this.billable='billable'
    }

}
