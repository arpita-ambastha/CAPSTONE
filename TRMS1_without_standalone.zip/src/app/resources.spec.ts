import { Resources } from './resources';

describe('Resources', () => {
  it('should create an instance', () => {
    expect(new Resources()).toBeTruthy();
  });
});
