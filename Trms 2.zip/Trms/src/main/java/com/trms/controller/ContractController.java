package com.trms.controller;

import java.io.IOException;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.text.SimpleDateFormat;
import java.text.DateFormat;


import com.trms.entity.Contract;
import com.trms.service.ContractService;

import ContractExcel.ContractExcel;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.servlet.http.HttpServletResponse;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ContractController {
 
	@Autowired
	ContractService contractServe;
	@GetMapping("/contracts")
	public List<Contract> getAllContracts(){
		return contractServe.getall();
	}
	
	@Autowired
	private EntityManager entityManager;
	
	@PostMapping("/newContract")
	public ResponseEntity<Contract> NewContract(@RequestBody Contract contract) {
		Contract createdUser = contractServe.newContract(contract);
		return new ResponseEntity<>(createdUser,HttpStatus.CREATED);
	
		
	}
	
	@GetMapping("/getByContractMgr/{name}")
	public ResponseEntity<List<Contract>> findByContractMgr(@PathVariable String name){
		
		List<Contract> mgr =  contractServe.findByContractMgr(name);
		if(mgr != null && !mgr.isEmpty()) {
			return new ResponseEntity<>(mgr,HttpStatus.FOUND);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/getByClientVP/{name}")
	public ResponseEntity<List<Contract>> findByClientVp(@PathVariable String name)throws Exception{
		
		List<Contract> mgr =  contractServe.findByclientVP(name);
		if(mgr != null && !mgr.isEmpty()) {
			return  new ResponseEntity<>(mgr,HttpStatus.FOUND);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	
	@GetMapping("/getByClientSVP/{name}")
	public ResponseEntity<List<Contract>> findByClientSvp(@PathVariable String name)throws Exception{
		
		List<Contract> mgr =  contractServe.findByclientSVP(name);
		if(mgr != null && !mgr.isEmpty()) {
			return  new ResponseEntity<>(mgr,HttpStatus.FOUND);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/getByClientDir/{name}")
	public ResponseEntity<List<Contract>> findByClientDir(@PathVariable String name)throws Exception{
		
		List<Contract> mgr =  contractServe.findByclientDir(name);
		if(mgr != null && !mgr.isEmpty()) {
			return  new ResponseEntity<>(mgr,HttpStatus.FOUND);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/getByoffshorePM/{name}")
	public ResponseEntity<List<Contract>> findByoffshorePM(@PathVariable String name)throws Exception{
		
		List<Contract> mgr =  contractServe.findByoffshorePM(name);
		if(mgr != null && !mgr.isEmpty()) {
			return  new ResponseEntity<>(mgr,HttpStatus.FOUND);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/getByoffshoreDM/{name}")
	public ResponseEntity<List<Contract>> findByoffshoreDM(@PathVariable String name)throws Exception{
		
		List<Contract> mgr =  contractServe.findByoffshoreDM(name);
		if(mgr != null && !mgr.isEmpty()) {
			return  new ResponseEntity<>(mgr,HttpStatus.FOUND);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PutMapping("/updateContract/{contract_Id}")
	public ResponseEntity<Contract> contract_Id(@RequestBody Contract contract,@PathVariable long contract_Id) throws Exception {
		Contract newEntity = contractServe.findById(contract_Id);
		if(newEntity != null) {
			Contract updatedEntity = contractServe.updateContract(contract,contract_Id);
			return new ResponseEntity<>(updatedEntity,HttpStatus.CREATED);
		}
		throw new Exception("Contract is not found with id : "+contract_Id);
	}
	
//	@PutMapping("/updateContract/{contractId}")
//	public Contract saveOrUpdate(@RequestBody Contract contract,@PathVariable Long contract_Id) throws Exception {
//		
//			
//			Contract newEntity = contractServe.findById(contract_Id);
//			System.out.println("Find By id : "+newEntity);
//			
//			if(newEntity != null) {
//				newEntity.setPrismId(contract.getPrismId());
//				newEntity.setOffshoreHC(contract.getOffshoreHC());
//				newEntity.setOnsiteHC(contract.getOnsiteHC());
//				newEntity.setOffsiteHC(contract.getOffsiteHC());
//				newEntity.setValueAddedResources(contract.getValueAddedResources());
//				newEntity.setOpco(contract.getOpco());
//				newEntity.setOnsitePM(contract.getOnsitePM());
//				newEntity.setOnsiteDM(contract.getOnsiteDM());
//				newEntity.setOffshorePM(contract.getOffshorePM());
//				newEntity.setOffshoreDM(contract.getOffshoreDM());
//				newEntity.setOffshoreDMSap(contract.getOffshoreDMSap());
//				newEntity.setOffshorePMSap(contract.getOffshorePMSap());
//				newEntity.setContractStartDate(contract.getContractStartDate());
//				newEntity.setContractEndDate(contract.getContractEndDate());
//				newEntity.setVendor(contract.getVendor());
//				newEntity.setsOWName(contract.getsOWName());
//				newEntity.setEngagementType(contract.getEngagementType());
//				newEntity.setContractType(contract.getContractType());
//				newEntity.setRelationship(contract.getRelationship());
//				newEntity.setCostManagement(contract.getCostManagement());
//				newEntity.setQuality(contract.getQuality());
//				newEntity.setDelivary(contract.getDelivary());
//				newEntity.setResources(contract.getResources());
//				newEntity.setRegion(contract.getRegion());
//				newEntity.setContractMgr(contract.getContractMgr());
//				newEntity.setContactDirector(contract.getContactDirector());
//				newEntity.setContactAccessNo(contract.getContactAccessNo());
//				newEntity.setContactAccessYes(contract.getContactAccessYes());
//				newEntity.setAdditionPMAcessSap(contract.getAdditionPMAcessSap());
//				newEntity.setClientManagerLDAP(contract.getClientManagerLDAP());
//				newEntity.setClientManager(contract.getClientManager());
//				newEntity.setClientDir(contract.getClientDir());
//				newEntity.setClientDirLDAP(contract.getClientDirLDAP());
//				newEntity.setClientVP(contract.getClientVP());
//				newEntity.setClientVPLDAP(contract.getClientVPLDAP());
//				newEntity.setClientSVP(contract.getClientSVP());
//				newEntity.setDefaultManager(false);
//				
//				Contract updatedEntity = contractServe.updateContract(contract, contract_Id);
//				
//				return updatedEntity;
//			}
//			else {
//			throw new Exception("Could not found Contract Id : "+contract_Id);
//			}
//			
//		}
	@GetMapping("/getContractById/{id}")
	public ResponseEntity<Contract>getContractById (@PathVariable long id) {
	Contract contract= contractServe.findById(id);
	return contract != null ? new
			ResponseEntity
			<>(contract, HttpStatus.OK) : new
			ResponseEntity
			<>(HttpStatus.NOT_FOUND);
	}
     
     
	    @GetMapping("/users/export/excel")
	    public void exportToExcel(HttpServletResponse response) throws IOException {
	        response.setContentType("application/octet-stream");
	        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
	        String currentDateTime = dateFormatter.format(new Date());
	         
	        String headerKey = "Content-Disposition";
	        String headerValue = "attachment; filename=users_" + currentDateTime + ".xlsx";
	        response.setHeader(headerKey, headerValue);
	         
	        List<Contract> listUsers = contractServe.getall();
	         
	        ContractExcel excelExporter = new ContractExcel(listUsers);
	         
	        excelExporter.export(response);    
	    }  
}
 