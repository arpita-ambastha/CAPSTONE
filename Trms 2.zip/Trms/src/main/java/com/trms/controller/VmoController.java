package com.trms.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.trms.entity.Contract;
import com.trms.entity.VmoEntity;
import com.trms.service.VmoService;

import VmoExcel.VmoContractExcel;
import VmoExcel.VmoExcel;
import jakarta.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
 
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class VmoController {
 
	@Autowired
	VmoService vmoservice;
	
	@GetMapping("/vmo")
	public List<VmoEntity> getAllContracts(){
		return vmoservice.getall();
	}
//	
//	@PostMapping("/addid")
//	public ResponseEntity<VmoEntity> NewVmoEntity(@RequestBody VmoEntity contract) {
//		VmoEntity  createdUser = vmoservice.newVmoEntity(contract);
//		return new ResponseEntity<>(createdUser,HttpStatus.CREATED);
//	}
//	
//	
//	@PutMapping("/update/{fedex_ID}")
//	public ResponseEntity<VmoEntity> update(@RequestBody VmoEntity vmo, @PathVariable Long fedex_ID ) throws Exception{
//		System.out.println(fedex_ID);
//		VmoEntity vm = vmoservice.findById(fedex_ID);
//		System.out.println(vm.getFedex_ID());
//		if(vm!=null) {
//			VmoEntity update=vmoservice.updateById(vmo);
//			System.out.println(update.getFedex_ID());
//			System.out.println(update.getSystemacess();
//			
//			return new ResponseEntity<>(update,HttpStatus.CREATED);
//		}
//		throw new Exception("Contract is not found with id : "+fedex_ID);
//		
//	}
 
	@PutMapping("/update/{fedex_ID}")
	public ResponseEntity<VmoEntity> update(@RequestBody VmoEntity vmo, @PathVariable Long fedex_ID ) throws Exception{
		VmoEntity vm = vmoservice.findById(fedex_ID);
			if(vm!=null) {
			VmoEntity update=vmoService.updateById(vmo);
			return new ResponseEntity<>(update,HttpStatus.CREATED);
	}
		throw new Exception("Contract is not found with id : "+ fedex_ID);
	}

 
	@Autowired
    private VmoService vmoService;
    @PostMapping("/createvmo")
    public ResponseEntity<VmoEntity> newVmoEntity(@RequestBody VmoEntity vmo) {
        VmoEntity createdVmo = vmoService.newVmoEntity(vmo);
        return new ResponseEntity<>(createdVmo, HttpStatus.CREATED);
    }
 

    @GetMapping("/vmo/{contractId}") // Changed to follow Java naming conventions
    public List<VmoEntity> getVmoByContractId(@PathVariable Long contractId) {
        return vmoService.findByContractId(contractId);
    }
    
    @GetMapping("/vmo/vmoexcel")
    public void exportToExcel(HttpServletResponse response) throws IOException {
        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=Resource_" + currentDateTime + ".xlsx";
        response.setHeader(headerKey, headerValue);
        List<VmoEntity> listvmoEntity = vmoservice.getall();
      VmoExcel excelExporter = new VmoExcel(listvmoEntity);
        excelExporter.export(response);    
    }
    @GetMapping("/vmo/contract/vmoexcel/{contractId}")
    public void VmoContractToExcel(HttpServletResponse response,@PathVariable long contractId) throws IOException {
        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=ContractResource_" + currentDateTime + ".xlsx";
        response.setHeader(headerKey, headerValue);
        List<VmoEntity> listvmoEntity = vmoservice.findByContractId(contractId);
        VmoContractExcel excelExporter = new VmoContractExcel(listvmoEntity);
        excelExporter.export(response);    
    }
}
