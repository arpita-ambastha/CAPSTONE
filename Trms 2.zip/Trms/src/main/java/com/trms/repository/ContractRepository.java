package com.trms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.trms.entity.Contract;

@EnableJpaRepositories
@Repository
public interface ContractRepository extends JpaRepository<Contract,Long> {
 
	List<Contract> findByContractMgr(String contractMgr);
	
	List<Contract> findByclientVP(String clientVP);
	
	List<Contract> findByclientSVP(String clientSVP);
	
	List<Contract> findByclientDir(String clientDir);
	
	List<Contract> findByoffshorePM(String offshorePM);
	
	List<Contract> findByoffshoreDM(String offshoreDM);
}