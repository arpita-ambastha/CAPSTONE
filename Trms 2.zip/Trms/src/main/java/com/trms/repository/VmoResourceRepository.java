package com.trms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trms.entity.VmoEntity;
import com.trms.entity.VmoResource;

public interface VmoResourceRepository extends JpaRepository<VmoResource,Long> {
	VmoResource findByfedexId(long fedexId);
	Optional<VmoResource> findTopByOrderBySIDesc();
	List<VmoResource> findByContractId(long contractId)throws Exception;
}

