package com.trms.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
 
@Entity
@Table(name="\"resources\"")
public class VmoResource {
 
	@Column(name="si")

	private long SI;
	
	

	@Id
	private long fedexId;
	
	private String Name;
	
	private String Placement;
	
	private String Billable;
	
	private boolean modify;
 
	private long contractId;
 
	public long getContractId() {
		return contractId;
	}

	public void setContractId(long contractId) {
		this.contractId = contractId;
	}

	public long getSI() {
		return SI;
	}
 
	public void setSI(long sI) {
		SI = sI;
	}
 
	public long getFedexId() {
		return fedexId;
	}
 
	public void setFedexId(long fedexId) {
		this.fedexId = fedexId;
	}
 
	public String getName() {
		return Name;
	}
 
	public void setName(String name) {
		Name = name;
	}
 
	public String getPlacement() {
		return Placement;
	}
 
	public void setPlacement(String placement) {
		Placement = placement;
	}
 
	public String getBillable() {
		return Billable;
	}
 
	public void setBillable(String billable) {
		Billable = billable;
	}
 
	public boolean isModify() {
		return modify;
	}
 
	public void setModify(boolean modify) {
		this.modify = modify;
	}
	
 

	
 
	public VmoResource() {
		super();
	}

public VmoResource(long sI, long fedexId, String name, String placement, String billable, boolean modify,
		long contractId) {
	super();
	SI = sI;
	this.fedexId = fedexId;
	this.Name = name;
	this.Placement = placement;
	this.Billable = billable;
	this.modify = modify;
	this.contractId = contractId;
}
 
	
 
	
}
 