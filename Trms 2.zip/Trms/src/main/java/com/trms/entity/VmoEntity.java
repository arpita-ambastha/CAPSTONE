package com.trms.entity;

import java.time.LocalDate;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "\"newVmo\"")
public class VmoEntity {
 
 
		@Id
		private long fedexId;
		private LocalDate fedex_IdRequestedDate;
		private LocalDate releaseRequestedDate;
		private String visatype;
		private String cardrole;
		private boolean fedexVenderBadge;
		private boolean l1certification;
		private boolean l2certification;
		private String mphasissecuritytraining;
		private long sapId;
		private LocalDate fedex_idcreationdate;
		private LocalDate releaseacknowledagedate;
		private String location;
		private String clientmanager1;
		private boolean bgvinitiation1;
		private String fedexsecuritytraining1;
		private boolean clearence;
		private String name;
		private String billable;
		private String placement;	
		private String companyname;
		private String systemacess;
		private boolean supplychain;
		private boolean hubstack;
		private boolean shipping;
		@ManyToOne
	 @JoinColumn(name = "contractId")
	  private Contract contract;
		//private long contractId;
		
		public long getFedexId() {
			return fedexId;
		}
		public void setFedexId(long fedexId) {
			this.fedexId = fedexId;
		}
		public LocalDate getFedex_IdRequestedDate() {
			return fedex_IdRequestedDate;
		}
		public void setFedex_IdRequestedDate(LocalDate fedex_IdRequestedDate) {
			this.fedex_IdRequestedDate = fedex_IdRequestedDate;
		}
		public LocalDate getReleaseRequestedDate() {
			return releaseRequestedDate;
		}
		public void setReleaseRequestedDate(LocalDate releaseRequestedDate) {
			this.releaseRequestedDate = releaseRequestedDate;
		}
		public String getVisatype() {
			return visatype;
		}
		public void setVisatype(String visatype) {
			this.visatype = visatype;
		}
		public String getCardrole() {
			return cardrole;
		}
		public void setCardrole(String cardrole) {
			this.cardrole = cardrole;
		}
		public boolean isFedexVenderBadge() {
			return fedexVenderBadge;
		}
		public void setFedexVenderBadge(boolean fedexVenderBadge) {
			this.fedexVenderBadge = fedexVenderBadge;
		}
		public Boolean getL1certification() {
			return l1certification;
		}
		public void setL1certification(Boolean l1certification) {
			this.l1certification = l1certification;
		}
		public Boolean getL2certification() {
			return l2certification;
		}
		public void setL2certification(Boolean l2certification) {
			this.l2certification = l2certification;
		}
		public String getMphasissecuritytraining() {
			return mphasissecuritytraining;
		}
		public void setMphasissecuritytraining(String mphasissecuritytraining) {
			this.mphasissecuritytraining = mphasissecuritytraining;
		}
		public long getSapId() {
			return sapId;
		}
		public void setSapId(long sapId) {
			this.sapId = sapId;
		}
		public LocalDate getFedex_idcreationdate() {
			return fedex_idcreationdate;
		}
		public void setFedex_idcreationdate(LocalDate fedex_idcreationdate) {
			this.fedex_idcreationdate = fedex_idcreationdate;
		}
		public LocalDate getReleaseacknowledagedate() {
			return releaseacknowledagedate;
		}
		public void setReleaseacknowledagedate(LocalDate releaseacknowledagedate) {
			this.releaseacknowledagedate = releaseacknowledagedate;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getClientmanager1() {
			return clientmanager1;
		}
		public void setClientmanager1(String clientmanager1) {
			this.clientmanager1 = clientmanager1;
		}
		public boolean isBgvinitiation1() {
			return bgvinitiation1;
		}
		public void setBgvinitiation1(boolean bgvinitiation1) {
			this.bgvinitiation1 = bgvinitiation1;
		}
		public String getFedexsecuritytraining1() {
			return fedexsecuritytraining1;
		}
		public void setFedexsecuritytraining1(String fedexsecuritytraining1) {
			this.fedexsecuritytraining1 = fedexsecuritytraining1;
		}
		public boolean isClearence() {
			return clearence;
		}
		public void setClearence(boolean clearence) {
			this.clearence = clearence;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getBillable() {
			return billable;
		}
		public void setBillable(String billable) {
			this.billable = billable;
		}
		public String getPlacement() {
			return placement;
		}
		public void setPlacement(String placement) {
			this.placement = placement;
		}
		public String getCompanyname() {
			return companyname;
		}
		public void setCompanyname(String companyname) {
			this.companyname = companyname;
		}
		public String getSystemacess() {
			return systemacess;
		}
		public void setSystemacess(String systemacess) {
			this.systemacess = systemacess;
		}
		public boolean isSupplychain() {
			return supplychain;
		}
		public void setSupplychain(boolean supplychain) {
			this.supplychain = supplychain;
		}
		public boolean isHubstack() {
			return hubstack;
		}
		public void setHubstack(boolean hubstack) {
			this.hubstack = hubstack;
		}
		public boolean isShipping() {
			return shipping;
		}
		public void setShipping(boolean shipping) {
			this.shipping = shipping;
		}
	public Contract getContract() {
			return contract;
		}
		public void setContract(Contract contract) {
			this.contract = contract;
		}  
	/*public long getContractId() {
			return contractId;
		}
		public void setContractId(long contractId) {
			this.contractId = contractId;
		} */
		public VmoEntity() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		
		
		

}
