package com.trms.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.trms.entity.User;
import com.trms.repository.UserRepository;

public class UserService {
	@Autowired
	UserRepository userRepository;
	User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

}
