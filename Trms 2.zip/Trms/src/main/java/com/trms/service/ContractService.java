package com.trms.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.trms.entity.Contract;

public interface ContractService {
	 
	List<Contract> findByContractMgr(String contractMgr);
	
	public Contract newContract(Contract contract);
	
	List<Contract> findByclientVP(String clientVP);
	
	List<Contract> findByclientSVP(String clientSVP);
	
	List<Contract> findByclientDir(String clientDir);
	
	List<Contract> findByoffshorePM(String offshorePM);
	
	List<Contract> findByoffshoreDM(String offshoreDM);
	
	public Contract findById(Long contract_Id);
	
	Contract updateContract(Contract contract,long id);
	List<Contract> getall();

	
}
 