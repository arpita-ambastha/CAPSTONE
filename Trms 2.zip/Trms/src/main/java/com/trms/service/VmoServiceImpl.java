package com.trms.service;

import java.util.List;

 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
 
import com.trms.entity.VmoEntity;
import com.trms.repository.VmoRepository;
 
@Service
public class VmoServiceImpl implements VmoService {
	  @Autowired
	    private VmoRepository vmoRepository;
	    @Override
	    public VmoEntity newVmoEntity(VmoEntity vmo) {
	        return vmoRepository.save(vmo);
	    }
	    @Override
	    public VmoEntity findById(Long fedexId) {
	        return vmoRepository.findById(fedexId).orElse(null);
	    }
	   @Override
	   public List<VmoEntity> findByContractId(Long contractId) {
	        return vmoRepository.findByContractContractId(contractId);
	    } 
		@Override
		public VmoEntity updateById(VmoEntity vmo) {
			return vmoRepository.save(vmo);
		}
		
		@Override
        public List<VmoEntity> getall() {
	      return vmoRepository.findAll();
}
 
 
		
 
}
