package com.trms.service;

import java.util.List;

import com.trms.entity.VmoEntity;
 
public interface VmoService {

    VmoEntity newVmoEntity(VmoEntity vmo);
    VmoEntity findById(Long fedexId);
    List<VmoEntity> findByContractId(Long contractId);
	VmoEntity updateById(VmoEntity vmo);
	
	List<VmoEntity> getall();
 
}