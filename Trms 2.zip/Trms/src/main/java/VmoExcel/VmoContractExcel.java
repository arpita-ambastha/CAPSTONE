package VmoExcel;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.trms.entity.Contract;
import com.trms.entity.VmoEntity;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
	public class VmoContractExcel {
		 private XSSFWorkbook workbook;
		    private XSSFSheet sheet;
		    private List<VmoEntity> listresource;
		    public VmoContractExcel(List<VmoEntity> listresource) {
		        this.listresource= listresource;
		        workbook = new XSSFWorkbook();
		    }

		    private void writeHeaderLine() {
		        sheet = workbook.createSheet("Users");
		        Row row = sheet.createRow(0);
		        CellStyle style = workbook.createCellStyle();
		        XSSFFont font = workbook.createFont();
		        font.setBold(true);
		        font.setFontHeight(16);
		        style.setFont(font);
		        createCell(row, 0, "Fedex_ID", style);      
		        createCell(row, 1, "Fedex_IdRequestedDate", style);       
		        createCell(row, 2, "ReleaseRequestedDate", style);    
		        createCell(row, 3, "visatype", style);
		        createCell(row, 4, "cardrole", style);
		        createCell(row, 5, "FedexVenderBadge", style);      
		        createCell(row, 6, "L1certification", style);       
		        createCell(row, 7, "L2certification", style);    
		        createCell(row, 8, "Mphasissecuritytraining", style);
		        createCell(row, 9, "SapId", style);
		        createCell(row, 10, "Fedex_idcreationdate", style);      
		        createCell(row, 11, "Releaseacknowledagedate", style);          
		        createCell(row, 12, "Location", style);
		        createCell(row, 13, "Clientmanager1", style);
		        createCell(row, 14, "BGVInitiation1", style);      
		        createCell(row, 15, "Fedexsecuritytraining1", style);       
		        createCell(row, 16, "Clearence", style);    
		        createCell(row, 17, "Name", style);
		        createCell(row, 18, "Billable", style);      
		        createCell(row, 19, "Placement", style);       
		        createCell(row, 20, "Companyname", style);    
		        createCell(row, 21, "Systemacess", style);
		        createCell(row, 22, "Supplychain", style);
		        createCell(row, 23, "Hubstack", style);
		        createCell(row, 24, "ContractId", style);      
		        createCell(row, 25, "prismId", style);       
		        createCell(row, 26, "offshoreHC", style);    
		        createCell(row, 27, "onsiteHC", style);
		        createCell(row, 28, "offsiteHC", style);
		        createCell(row, 29, "valueAddedResources", style);      
		        createCell(row, 30, "opco", style);       
		        createCell(row, 31, "onsitePM", style);    
		        createCell(row, 32, "onsiteDM", style);
		        createCell(row, 33, "offshorePM", style);
		        createCell(row, 34, "offshoreDM", style);      
		        createCell(row, 35, "offshoreDMSap", style);       
		        createCell(row, 36, "offshorePMSap", style);    
		        createCell(row, 37, "contractStartDate", style);
		        createCell(row, 38, "contractEndDate", style);
		        createCell(row, 39, " vendor", style);      
		        createCell(row, 40, "sOWName", style);       
		        createCell(row, 41, "engagementType", style);    
		        createCell(row, 42, "contractType", style);
		        createCell(row, 43, "relationship", style);
		        createCell(row, 44, "costManagement", style);      
		        createCell(row, 45, "quality", style);       
		        createCell(row, 46, " delivary", style);    
		        createCell(row, 47, "resources", style);
		        createCell(row, 48, "region", style);
		        createCell(row, 49, "contractMgr", style);      
		        createCell(row, 50, "contactDirector", style);    
		        createCell(row, 51, "contactAccessYes", style);      
		        createCell(row, 52, "contactAccessNo", style);       
		        createCell(row, 53, "additionPMAcessSap", style);    
		        createCell(row, 54, "clientManager", style);
		        createCell(row, 55, "clientManagerLDAP", style);
		        createCell(row, 56, " clientDir", style);      
		        createCell(row, 57, "clientDirLDAP", style);    
		        createCell(row, 58, "clientVP", style);      
		        createCell(row, 59, "clientVPLDAP", style);       
		        createCell(row, 60, "clientSVP", style);    
		        createCell(row, 61, "DefaultManager", style);
		    }
		    private void createCell(Row row, int columnCount, Object value, CellStyle style) {
		        sheet.autoSizeColumn(columnCount);
		        Cell cell = row.createCell(columnCount);
		        if (value instanceof Integer) {
		            cell.setCellValue((Integer) value);
		        } else if (value instanceof Boolean) {
		            cell.setCellValue((Boolean) value);
		        }
		            else if(value instanceof String) {
			            cell.setCellValue((String) value);
			        }
			        else if (value instanceof Long) {
			            cell.setCellValue((Long) value);
			        }
			        else if (value instanceof Float){
			            cell.setCellValue((Float) value);
			        }
			        else {
			        	LocalDate val=LocalDate.now();
			        	String formateDate =val.toString();
			        			cell.setCellValue(formateDate);
			        }
		        cell.setCellStyle(style);
		    }
		    private void writeDataLines() {
		        int rowCount = 1;
		        CellStyle style = workbook.createCellStyle();
		        XSSFFont font = workbook.createFont();
		        font.setFontHeight(14);
		        style.setFont(font);
		        for (VmoEntity resource : listresource) {
		            Row row = sheet.createRow(rowCount++);
		            int columnCount = 0;
		            createCell(row, columnCount++, resource.getFedexId(), style);
		            createCell(row, columnCount++, resource.getFedex_IdRequestedDate(), style);
		            createCell(row, columnCount++, resource.getReleaseRequestedDate(), style);
		            createCell(row, columnCount++, resource.getVisatype().toString(), style);
		            createCell(row, columnCount++, resource.getCardrole().toString(), style);
		            createCell(row, columnCount++, resource.isFedexVenderBadge(), style);
		            createCell(row, columnCount++, resource.getL1certification(), style);
		            createCell(row, columnCount++, resource.getL2certification(), style);
		            createCell(row, columnCount++, resource.getMphasissecuritytraining(), style);
		            createCell(row, columnCount++, resource.getSapId(), style);
		            createCell(row, columnCount++, resource.getFedex_idcreationdate(), style);
		            createCell(row, columnCount++, resource.getReleaseacknowledagedate(), style);
		            createCell(row, columnCount++, resource.getLocation().toString(), style);
		            createCell(row, columnCount++, resource.getClientmanager1().toString(), style);
		            createCell(row, columnCount++, resource.isBgvinitiation1(), style);
		            createCell(row, columnCount++, resource.getFedexsecuritytraining1().toString(), style);
		            createCell(row, columnCount++, resource.isClearence(), style);
		            createCell(row, columnCount++, resource.getName().toString(), style);
		            createCell(row, columnCount++, resource.getBillable().toString(), style);
		            createCell(row, columnCount++, resource.getPlacement().toString(), style);
		            createCell(row, columnCount++, resource.getCompanyname().toString(), style);
		            createCell(row, columnCount++, resource.getSystemacess().toString(), style);
		            createCell(row, columnCount++, resource.isSupplychain(), style);
		            createCell(row, columnCount++, resource.isHubstack(), style);
		            createCell(row, columnCount++, resource.getContract().getContractId(), style);
		            createCell(row, columnCount++, resource.getContract().getPrismId(), style);
		            createCell(row, columnCount++, resource.getContract().getOffshoreHC(), style);
		            createCell(row, columnCount++, resource.getContract().getOnsiteHC(), style);
		            createCell(row, columnCount++, resource.getContract().getOffsiteHC(), style);
		            createCell(row, columnCount++, resource.getContract().getValueAddedResources(), style);
		            createCell(row, columnCount++, resource.getContract().getOpco(), style);
		            createCell(row, columnCount++, resource.getContract().getOnsitePM(), style);
		            createCell(row, columnCount++, resource.getContract().getOnsiteDM(), style);
		            createCell(row, columnCount++, resource.getContract().getOffshorePM(), style);
		            createCell(row, columnCount++, resource.getContract().getOffshoreDM(), style);
		            createCell(row, columnCount++, resource.getContract().getOffshoreDMSap(),style);
		            createCell(row, columnCount++, resource.getContract().getOffshorePMSap(), style);
		            createCell(row, columnCount++, resource.getContract().getContractStartDate(), style);
		            createCell(row, columnCount++, resource.getContract().getContractEndDate(), style);
		            createCell(row, columnCount++, resource.getContract().getVendor(), style);
		            createCell(row, columnCount++, resource.getContract().getsOWName(),style);
		            createCell(row, columnCount++, resource.getContract().getEngagementType(), style);
		            createCell(row, columnCount++, resource.getContract().getContractType(), style);
		            createCell(row, columnCount++, resource.getContract().getRelationship(), style);
		            createCell(row, columnCount++, resource.getContract().getCostManagement(), style);
		            createCell(row, columnCount++, resource.getContract().getQuality(), style);
		            createCell(row, columnCount++, resource.getContract().getDelivary(), style);
		            createCell(row, columnCount++, resource.getContract().getResources(), style);
		            createCell(row, columnCount++, resource.getContract().getRegion(), style);
		            createCell(row, columnCount++, resource.getContract().getContractMgr(), style);
		            createCell(row, columnCount++, resource.getContract().getContactDirector(), style);
		            createCell(row, columnCount++, resource.getContract().getContactAccessYes(), style);
		            createCell(row, columnCount++, resource.getContract().getContactAccessNo(), style);
		            createCell(row, columnCount++, resource.getContract().getAdditionPMAcessSap(), style);
		            createCell(row, columnCount++, resource.getContract().getClientManager(), style);
		            createCell(row, columnCount++, resource.getContract().getClientManagerLDAP(), style);
		            createCell(row, columnCount++, resource.getContract().getClientDir(), style);
		            createCell(row, columnCount++, resource.getContract().getClientDirLDAP(), style);
		            createCell(row, columnCount++, resource.getContract().getClientVP(), style);
		            createCell(row, columnCount++, resource.getContract().getClientVPLDAP(), style);
		            createCell(row, columnCount++, resource.getContract().getClientSVP(),style);
		            createCell(row, columnCount++, resource.getContract().isDefaultManager(),style);

		        }
		    }
		    private CellStyle isDefaultManager() {
				// TODO Auto-generated method stub
				return null;
			}

			private CellStyle getClientSVP() {
				// TODO Auto-generated method stub
				return null;
			}

			public void export(HttpServletResponse response) throws IOException {
		        writeHeaderLine();
		        writeDataLines();
		        ServletOutputStream outputStream = response.getOutputStream();
		        workbook.write(outputStream);
		        workbook.close();
		        outputStream.close();
		    }
	}