package VmoExcel;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.trms.entity.Contract;
import com.trms.entity.VmoEntity;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

	public class VmoExcel {
		 private XSSFWorkbook workbook;
		    private XSSFSheet sheet;
		    private List<VmoEntity> listvmoEntity;
		    public VmoExcel(List<VmoEntity> listvmoEntity) {
		        this.listvmoEntity= listvmoEntity;
		        workbook = new XSSFWorkbook();
		    }

		    private void writeHeaderLine() {
		        sheet = workbook.createSheet("Users");
		        Row row = sheet.createRow(0);
		        CellStyle style = workbook.createCellStyle();
		        XSSFFont font = workbook.createFont();
		        font.setBold(true);
		        font.setFontHeight(16);
		        style.setFont(font);
		        createCell(row, 0, "Fedex_ID", style);      
		        createCell(row, 1, "Fedex_IdRequestedDate", style);       
		        createCell(row, 2, "ReleaseRequestedDate", style);    
		        createCell(row, 3, "visatype", style);
		        createCell(row, 4, "cardrole", style);
		        createCell(row, 5, "FedexVenderBadge", style);      
		        createCell(row, 6, "L1certification", style);       
		        createCell(row, 7, "L2certification", style);    
		        createCell(row, 8, "Mphasissecuritytraining", style);
		        createCell(row, 9, "SapId", style);
		        createCell(row, 10, "Fedex_idcreationdate", style);      
		        createCell(row, 11, "Releaseacknowledagedate", style);       
		        createCell(row, 12, "ReleaseRequestedDate", style);    
		        createCell(row, 13, "Location", style);
		        createCell(row, 14, "Clientmanager1", style);
		        createCell(row, 15, "BGVInitiation1", style);      
		        createCell(row, 16, "Fedexsecuritytraining1", style);       
		        createCell(row, 17, "Clearence", style);    
		        createCell(row, 18, "Name", style);
		        createCell(row, 19, "Billable", style);      
		        createCell(row, 20, "Placement", style);       
		        createCell(row, 21, "Companyname", style);    
		        createCell(row, 22, "Systemacess", style);
		        createCell(row, 23, "Supplychain", style);
		        createCell(row, 24, "Hubstack", style);
		    }
		    private void createCell(Row row, int columnCount, Object value, CellStyle style) {
		        sheet.autoSizeColumn(columnCount);
		        Cell cell = row.createCell(columnCount);
		        if (value instanceof Integer) {
		            cell.setCellValue((Integer) value);
		        } else if (value instanceof Boolean) {
		            cell.setCellValue((Boolean) value);
		        }
		            else if(value instanceof String) {
			            cell.setCellValue((String) value);
			        }
			        else if (value instanceof Long) {
			            cell.setCellValue((Long) value);
			        }
			        else if (value instanceof Float){
			            cell.setCellValue((Float) value);
			        }
			        else {
			        	LocalDate val=LocalDate.now();
			        	String formateDate =val.toString();
			        			cell.setCellValue(formateDate);
			        }
		        cell.setCellStyle(style);
		    }
		    private void writeDataLines() {
		        int rowCount = 1;
		        CellStyle style = workbook.createCellStyle();
		        XSSFFont font = workbook.createFont();
		        font.setFontHeight(14);
		        style.setFont(font);
		        for (VmoEntity contract : listvmoEntity) {
		            Row row = sheet.createRow(rowCount++);
		            int columnCount = 0;
		            createCell(row, columnCount++, contract.getFedexId(), style);
		            createCell(row, columnCount++, contract.getFedex_IdRequestedDate(), style);
		            createCell(row, columnCount++, contract.getReleaseRequestedDate(), style);
		            createCell(row, columnCount++, contract.getVisatype().toString(), style);
		            createCell(row, columnCount++, contract.getCardrole().toString(), style);
		            createCell(row, columnCount++, contract.isFedexVenderBadge(), style);
		            createCell(row, columnCount++, contract.getL1certification(), style);
		            createCell(row, columnCount++, contract.getL2certification(), style);
		            createCell(row, columnCount++, contract.getMphasissecuritytraining(), style);
		            createCell(row, columnCount++, contract.getSapId(), style);
		            createCell(row, columnCount++, contract.getFedex_idcreationdate(), style);
		            createCell(row, columnCount++, contract.getReleaseacknowledagedate(), style);
		            createCell(row, columnCount++, contract.getLocation().toString(), style);
		            createCell(row, columnCount++, contract.getClientmanager1().toString(), style);
		            createCell(row, columnCount++, contract.isBgvinitiation1(), style);
		            createCell(row, columnCount++, contract.getFedexsecuritytraining1().toString(), style);
		            createCell(row, columnCount++, contract.isClearence(), style);
		            createCell(row, columnCount++, contract.getName().toString(), style);
		            createCell(row, columnCount++, contract.getBillable().toString(), style);
		            createCell(row, columnCount++, contract.getPlacement().toString(), style);
		            createCell(row, columnCount++, contract.getCompanyname().toString(), style);
		            createCell(row, columnCount++, contract.getSystemacess().toString(), style);
		            createCell(row, columnCount++, contract.isSupplychain(), style);
		            createCell(row, columnCount++, contract.isHubstack(), style);
		        }
		    }
		    public void export(HttpServletResponse response) throws IOException {
		        writeHeaderLine();
		        writeDataLines();
		        ServletOutputStream outputStream = response.getOutputStream();
		        workbook.write(outputStream);
		        workbook.close();
		        outputStream.close();
		    }
	}